public class Account {
    int accountNumber;
    String customerName;
    double accountBalance;
public Account(int accountNumber, String name,double Balance)
{
    this.accountNumber = accountNumber;
    this.customerName = name;
    this.accountBalance = Balance;
}


}
